:mod:`pwnlib.replacements` --- Replacements for various functions
=================================================================

.. automodule:: pwnlib.replacements
   :members:
