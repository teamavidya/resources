.. testsetup:: *

   from pwnlib import shellcraft

:mod:`pwnlib.shellcraft` --- Shellcode generation
=================================================

.. automodule:: pwnlib.shellcraft

.. TODO:

   Write a guide to adding more shellcode.

Submodules
----------

.. toctree::
   :glob:

   shellcraft/*
