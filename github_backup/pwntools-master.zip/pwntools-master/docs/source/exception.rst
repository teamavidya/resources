:mod:`pwnlib.exception` --- Pwnlib exceptions
====================================================

.. automodule:: pwnlib.exception
   :members:
