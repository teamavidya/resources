.. testsetup:: *

    from pwnlib.regsort import *

:mod:`pwnlib.regsort` --- Register sorting
===========================================================

.. automodule:: pwnlib.regsort
   :members:
