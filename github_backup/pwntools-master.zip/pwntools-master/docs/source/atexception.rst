:mod:`pwnlib.atexception` --- Callbacks on unhandled exception
==============================================================

.. automodule:: pwnlib.atexception
   :members:
