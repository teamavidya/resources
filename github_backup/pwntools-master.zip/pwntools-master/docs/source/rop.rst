.. testsetup:: *

   from pwnlib.elf import *
   from pwnlib.rop import *
   from pwnlib.util.misc import which

:mod:`pwnlib.rop` --- Return Oriented Programming
=================================================

.. automodule:: pwnlib.rop
   :members:
