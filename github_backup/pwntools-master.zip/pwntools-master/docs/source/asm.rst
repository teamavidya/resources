.. testsetup:: *

   import tempfile
   import os
   from pwnlib.context import context
   from pwnlib.asm import *
   from pwnlib import shellcraft
   from pwnlib.tubes.process import process


:mod:`pwnlib.asm` --- Assembler functions
=========================================

.. automodule:: pwnlib.asm
   :members:
