.. testsetup:: *

   from pwnlib.util.lists import *

:mod:`pwnlib.util.lists` --- Operations on lists
================================================

.. automodule:: pwnlib.util.lists
   :members:
