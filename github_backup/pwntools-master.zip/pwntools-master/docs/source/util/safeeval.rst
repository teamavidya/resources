.. testsetup:: *

   from pwnlib.util.safeeval import *


:mod:`pwnlib.util.safeeval` --- Safe evaluation of python code
==============================================================

.. automodule:: pwnlib.util.safeeval
   :members:
