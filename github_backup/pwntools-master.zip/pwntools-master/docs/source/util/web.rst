.. testsetup:: *

   from pwnlib.context import context
   from pwnlib.util.web import *

:mod:`pwnlib.util.web` --- Utilities for working with the WWW
=============================================================

.. automodule:: pwnlib.util.web
   :members:
