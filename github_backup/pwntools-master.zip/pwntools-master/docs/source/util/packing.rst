.. testsetup:: *

   from pwnlib.util.packing import *


:mod:`pwnlib.util.packing` --- Packing and unpacking of strings
===============================================================

.. automodule:: pwnlib.util.packing
   :members:
