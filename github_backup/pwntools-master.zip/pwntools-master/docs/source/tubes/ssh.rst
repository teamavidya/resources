.. testsetup:: *

   from pwn import *

:mod:`pwnlib.tubes.ssh` --- SSH
===========================================================

.. automodule:: pwnlib.tubes.ssh

   .. autoclass:: pwnlib.tubes.ssh.ssh
      :members:

   .. autoclass:: pwnlib.tubes.ssh.ssh_channel()
      :members: kill, poll, interactive
      :show-inheritance:

   .. autoclass:: pwnlib.tubes.ssh.ssh_connecter()
      :show-inheritance:

   .. autoclass:: pwnlib.tubes.ssh.ssh_listener()
      :show-inheritance:
