.. testsetup:: *

   from pwn import *

:mod:`pwnlib.tubes.process` --- Processes
===========================================================

.. automodule:: pwnlib.tubes.process

  .. autoclass:: pwnlib.tubes.process.process
     :members: kill, poll, communicate
     :show-inheritance:
