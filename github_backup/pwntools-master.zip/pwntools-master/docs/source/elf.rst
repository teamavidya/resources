.. testsetup:: *

   from pwnlib.elf import *
   from pwnlib.util.misc import which

:mod:`pwnlib.elf` --- Working with ELF binaries
===============================================

.. automodule:: pwnlib.elf
   :members:
