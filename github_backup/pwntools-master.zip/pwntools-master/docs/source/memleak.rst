.. testsetup:: *

   from pwnlib.memleak import *

:mod:`pwnlib.memleak` --- Helper class for leaking memory
=========================================================

.. module:: pwnlib.memleak

.. autoclass:: MemLeak
   :members:
