.. testsetup:: *

   from pwnlib import constants
   from pwnlib.context import context

:mod:`pwnlib.constants` --- Easy access to header file constants
================================================================

.. automodule:: pwnlib.constants
