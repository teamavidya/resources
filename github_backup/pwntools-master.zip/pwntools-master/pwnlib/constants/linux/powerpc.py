from pwnlib.constants.constant import Constant
