#define __arm__
#include <arm/syscalls.h>
#include <common.h>
