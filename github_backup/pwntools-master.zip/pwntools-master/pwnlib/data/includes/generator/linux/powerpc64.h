#define __ppc64__
#include <ppc64/syscalls.h>
#include <common.h>
