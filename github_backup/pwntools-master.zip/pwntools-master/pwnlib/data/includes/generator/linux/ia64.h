#define __ia64__
#include <ia64/syscalls.h>
#include <common.h>
