#define __ppc__
#include <ppc/syscalls.h>
#include <common.h>
