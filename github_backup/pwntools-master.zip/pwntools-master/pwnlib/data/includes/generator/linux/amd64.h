#define __x86_64__
#include <x86_64/syscalls.h>
#include <x86_64/syscalls32.h>
#include <common.h>
