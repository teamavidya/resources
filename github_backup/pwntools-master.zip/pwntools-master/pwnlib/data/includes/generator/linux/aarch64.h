#define __arm__
#define __aarch64__
#include <aarch64/syscalls.h>
#include <common.h>
